@extends('layout.principal')

@section('conteudo')
<form action="/adiciona" method="post">
	<input name="_token" type="hidden" value="{{ csrf_token() }}">
	<input name="id" type="hidden" value="{{ $v->id or ''}}">
	<div class="form-group">
		<label>Nota Fiscal: </label>
		<input name="notaFiscal" value="{{ $v->notaFiscal or ''}}" class="form-control"/>
	</div>
	<div class="form-group">
		<label>Valor: </label>
		<input name="valor" value="{{ $v->valor or ''}}" class="form-control"/>
	</div>
	<div class="form-group">
		<label>Descrição: </label>
		<input name="descricao" value="{{ $v->descricao or ''}}" class="form-control"/>
	</div>
	<button class="btn btn-primary" type="submit">Adicionar</button>
</form>
@stop
