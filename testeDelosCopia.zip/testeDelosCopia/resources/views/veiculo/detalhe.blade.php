@extends('layout.principal')

@section('conteudo')
	<!-- O framework no arquivo que contem .blade, tem um opcional de não precisar a tag <?php ?> é so trocar por duas chaves e o codigo php entre elas -->
	<h1>Detalhes do veiculo</h1>

	<ul>
		<li>
			Id: {{$v->id}}
		</li>
		<li>
			Data emissão: {{$v->dataEmissao}}
		</li>
		<li>
			Nota fiscal: {{$v->notaFiscal}}
		</li>
		<li>
			Valor: R${{$v->valor}}
		</li>
		<li>
			<!-- Aqui tem um "or" onde o .blade da essa opção tambem que seria caso não tenha descriçao ele coloca o proxima do "or" -->
			Descrição: {{$v->descricao or 'Não tem descrição'}}
		</li>
		<li>
			Observação: {{$v->observacao}}
		</li>
		<li>
			Data Criação: {{$v->dataCriacao}}
		</li>
		<li>
			Data Atualização: {{$v->dataAtualizacao}}
		</li>
	</ul>
@stop
