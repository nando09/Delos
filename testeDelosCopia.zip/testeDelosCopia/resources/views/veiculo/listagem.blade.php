@extends('layout.principal')
@section('conteudo')
	@if(empty($veiculos))
		<div class="alert alert-danger" role="alert">Você não tem nenhum produto cadastrado.</div>
	@else
	<h1>Listagem de veiculos</h1>
	<table class="table table-striped table-bordered table-hover">
		<tr class="text-center font-weight-bold">
			<td>NotaFiscal</td>
			<td>Valor</td>
			<td>DataCriacao</td>
			<td>DataAtualizacao</td>
			<td class="text-center">
			</td>
			<td class="text-center">
			</td>
		</tr>
		@foreach($veiculos as $v)
		<tr">
			<td> {{ $v->notaFiscal }} </td>
			<td> {{ $v->valor }} </td>
			<td> {{ $v->dataCriacao }} </td>
			<td> {{ $v->dataAtualizacao }} </td>
			<td class="text-center">
				<a href="/ver/{{ $v->id }}">Ver</a>
			</td>
			<td class="text-center">
				<a href="/editar/{{ $v->id }}">Editar</a>
			</td>
			<td class="text-center">
				<a href="/remove/{{ $v->id }}">Remove</a>
			</td>
		</tr>
		@endforeach
	</table>
	@endif
@stop
