<?php $__env->startSection('conteudo'); ?>
	<?php if(empty($veiculos)): ?>
		<div class="alert alert-danger" role="alert">Você não tem nenhum produto cadastrado.</div>
	<?php else: ?>
	<h1>Listagem de veiculos</h1>
	<table class="table table-striped table-bordered table-hover">
		<tr class="text-center font-weight-bold">
			<td>NotaFiscal</td>
			<td>Valor</td>
			<td>DataCriacao</td>
			<td>DataAtualizacao</td>
			<td class="text-center">
			</td>
			<td class="text-center">
			</td>
		</tr>
		<?php $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr">
			<td> <?php echo e($v->notaFiscal); ?> </td>
			<td> <?php echo e($v->valor); ?> </td>
			<td> <?php echo e($v->dataCriacao); ?> </td>
			<td> <?php echo e($v->dataAtualizacao); ?> </td>
			<td class="text-center">
				<a href="/ver/<?php echo e($v->id); ?>">Ver</a>
			</td>
			<td class="text-center">
				<a href="/editar/<?php echo e($v->id); ?>">Editar</a>
			</td>
			<td class="text-center">
				<a href="/remove/<?php echo e($v->id); ?>">Remove</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>