<?php $__env->startSection('conteudo'); ?>
	<!-- O framework no arquivo que contem .blade, tem um opcional de não precisar a tag <?php ?> é so trocar por duas chaves e o codigo php entre elas -->
	<h1>Detalhes do veiculo</h1>

	<ul>
		<li>
			Id: <?php echo e($v->id); ?>

		</li>
		<li>
			Data emissão: <?php echo e($v->dataEmissao); ?>

		</li>
		<li>
			Nota fiscal: <?php echo e($v->notaFiscal); ?>

		</li>
		<li>
			Valor: R$<?php echo e($v->valor); ?>

		</li>
		<li>
			<!-- Aqui tem um "or" onde o .blade da essa opção tambem que seria caso não tenha descriçao ele coloca o proxima do "or" -->
			Descrição: <?php echo e(isset($v->descricao) ? $v->descricao : 'Não tem descrição'); ?>

		</li>
		<li>
			Observação: <?php echo e($v->observacao); ?>

		</li>
		<li>
			Data Criação: <?php echo e($v->dataCriacao); ?>

		</li>
		<li>
			Data Atualização: <?php echo e($v->dataAtualizacao); ?>

		</li>
	</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>