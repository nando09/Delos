<?php

namespace delos\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use delos\Veiculo;
use delos\Http\Requests\VeiculoRequest;

class VeiculoController extends Controller
{
	public function lista(){
		$veiculos = Veiculo::all();
		return view('veiculo.listagem')->with('veiculos', $veiculos);
	}

	public function mostra($id){
		$veiculos = Veiculo::find($id);
		if (empty($veiculos)){
			return 'Esse veiculos não existe';
		}

		return view('veiculo.detalhe')->with('v', $veiculos);
	}

	public function editar($id){
		$veiculo = Veiculo::find($id);
		return view('formulario')->with('v', $veiculo);
	}


	public function adiciona(VeiculoRequest $request){
		if(empty($request['id'])){
		DB::insert('insert into veiculos (`dataEmissao`, `notaFiscal`, `valor`, `descricao`, `observacao`, `dataCriacao`, `dataAtualizacao`) values (?, ?, ?, ?, ?, ?, ?)', array(NOW(), $request['notaFiscal'], $request['valor'], $request['descricao'], 0, NOW(), NOW()));
		}else{
			DB::update('update veiculos set notaFiscal = ?, valor = ?, descricao = ?, dataAtualizacao = ? where id = ?', array($request['notaFiscal'], $request['valor'], $request['descricao'], NOW(), $request['id']));
		}

		return redirect()->action('VeiculoController@lista');
	}

	public function remove($id){
		$veiculo = Veiculo::find($id);
		$veiculo->delete();
		return redirect()->action('VeiculoController@lista');
	}

	public function novo(){
		return view('formulario');
	}

	public function listaJson(){
		$veiculos = DB::select('select * from veiculos');
		return response()->json($veiculos);
	}
}
