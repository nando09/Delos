<?php

namespace delos;

use Illuminate\Database\Eloquent\Model;

class Veiculo extends Model
{
	//O banco de dados por padrao quer que você insira os valores de updated_at(que seria data de criação e de atualização), então vamos desativar essa padrao
	public $timestamps = false;

	//Aqui estou falando que so quero que seja preenchido esses campos
	protected $fillable = array('notaFiscal', 'valor', 'descricao');
}
