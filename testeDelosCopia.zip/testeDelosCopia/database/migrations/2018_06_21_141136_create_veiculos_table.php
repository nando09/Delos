<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVeiculosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('veiculos', function (Blueprint $table) {
            $table->increments('id')->autoIncrement();
            $table->date('dataEmissao');
            $table->string('notaFiscal');
            $table->double('valor', 8, 2);
            $table->text('descricao');
            $table->boolean('observacao');
            $table->dateTime('dataCriacao');
            $table->dateTime('dataAtualizacao');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('veiculos');
    }
}
