<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/json', 'VeiculoController@listaJson');
Route::get('/', 'VeiculoController@lista');
Route::get('/novo', 'VeiculoController@novo');
Route::get('/remove/{id}', 'VeiculoController@remove')->where('id', '[0-9]+');
Route::get('/editar/{id}', 'VeiculoController@editar')->where('id', '[0-9]+');
Route::get('/ver/{id}', 'VeiculoController@mostra')->where('id', '[0-9]+');

Route::post('/adiciona', 'VeiculoController@adiciona');
